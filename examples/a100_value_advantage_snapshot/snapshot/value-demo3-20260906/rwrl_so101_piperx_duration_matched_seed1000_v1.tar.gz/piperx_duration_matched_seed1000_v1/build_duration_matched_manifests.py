#!/usr/bin/env python3
"""Build portable, deterministic episode subsets matched to a target frame count."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


DEFAULT_SUBSETS = (
    "so101_fold_clothes_left_stack_right",
    "so101_put_stationery_table_into_bag",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rank_digest(
    namespace: str,
    repo_id: str,
    revision: str,
    seed: int,
    subset: str,
    episode_index: int,
) -> bytes:
    payload = json.dumps(
        [namespace, repo_id, revision, seed, subset, episode_index],
        ensure_ascii=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).digest()


def read_episodes(dataset_root: Path, subset: str) -> tuple[list[tuple[int, int]], list[Path]]:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise SystemExit("pyarrow is required: python -m pip install pyarrow") from exc

    metadata_dir = dataset_root / subset / "meta" / "episodes"
    files = sorted(metadata_dir.glob("**/*.parquet"))
    if not files:
        raise FileNotFoundError(f"No episode metadata parquet files under {metadata_dir}")

    episodes: list[tuple[int, int]] = []
    for path in files:
        table = pq.read_table(path, columns=["episode_index", "length"])
        indices = table.column("episode_index").to_pylist()
        lengths = table.column("length").to_pylist()
        episodes.extend((int(index), int(length)) for index, length in zip(indices, lengths, strict=True))

    indices = [index for index, _ in episodes]
    if len(indices) != len(set(indices)):
        raise ValueError(f"Duplicate episode_index values found for {subset}")
    if any(length <= 0 for _, length in episodes):
        raise ValueError(f"Non-positive episode length found for {subset}")
    return episodes, files


def select_nearest_prefix(
    episodes: list[tuple[int, int]],
    *,
    namespace: str,
    repo_id: str,
    revision: str,
    seed: int,
    subset: str,
    target_frames: int,
) -> list[tuple[int, int]]:
    ranked = sorted(
        episodes,
        key=lambda item: (
            rank_digest(namespace, repo_id, revision, seed, subset, item[0]),
            item[0],
        ),
    )
    selected: list[tuple[int, int]] = []
    selected_frames = 0
    for episode in ranked:
        selected.append(episode)
        selected_frames += episode[1]
        if selected_frames >= target_frames:
            break

    if not selected:
        raise ValueError("Cannot select from an empty episode collection")

    without_last = selected_frames - selected[-1][1]
    if abs(without_last - target_frames) < abs(selected_frames - target_frames):
        selected.pop()
    return selected


def build_manifest(args: argparse.Namespace, subset: str) -> dict[str, Any]:
    episodes, metadata_files = read_episodes(args.dataset_root, subset)
    selected = select_nearest_prefix(
        episodes,
        namespace=args.namespace,
        repo_id=args.repo_id,
        revision=args.revision,
        seed=args.seed,
        subset=subset,
        target_frames=args.target_frames,
    )

    ranked_indices = [index for index, _ in selected]
    sorted_indices = sorted(ranked_indices)
    selected_frames = sum(length for _, length in selected)
    compact_indices = json.dumps(ranked_indices, separators=(",", ":")).encode("utf-8")

    info_path = args.dataset_root / subset / "meta" / "info.json"
    if not info_path.is_file():
        raise FileNotFoundError(f"Missing dataset info: {info_path}")
    info = json.loads(info_path.read_text(encoding="utf-8"))
    source_frames = sum(length for _, length in episodes)
    if int(info["fps"]) != args.fps:
        raise ValueError(f"FPS mismatch for {subset}: {info['fps']} != {args.fps}")
    if int(info["total_episodes"]) != len(episodes):
        raise ValueError(f"Episode-count mismatch for {subset}")
    if int(info["total_frames"]) != source_frames:
        raise ValueError(f"Frame-count mismatch for {subset}")

    return {
        "schema_version": 1,
        "source": {
            "repo_id": args.repo_id,
            "revision": args.revision,
            "subset": subset,
            "fps": args.fps,
            "total_episodes": len(episodes),
            "total_frames": source_frames,
            "info": {
                "path": str(info_path.relative_to(args.dataset_root / subset)),
                "sha256": sha256_file(info_path),
                "codebase_version": info.get("codebase_version"),
            },
            "episode_metadata": [
                {
                    "path": str(path.relative_to(args.dataset_root / subset)),
                    "sha256": sha256_file(path),
                }
                for path in metadata_files
            ],
        },
        "target": {
            "reference_subset": args.reference_subset,
            "frames": args.target_frames,
            "hours_at_fps": args.target_frames / args.fps / 3600,
        },
        "sampling": {
            "algorithm": "sha256_identity_ranked_nearest_prefix_v1",
            "namespace": args.namespace,
            "seed": args.seed,
            "rank_key": (
                "sha256(UTF-8 compact JSON array "
                "[namespace, repo_id, revision, seed, subset, episode_index])"
            ),
            "sampling_unit": "whole episode",
            "replacement": False,
            "boundary_rule": (
                "Take the SHA-256-ranked prefix that first reaches target_frames, then compare it "
                "with the prefix excluding the final episode; keep the closer total. Ties keep the "
                "prefix that reaches or exceeds the target."
            ),
        },
        "selection": {
            "episode_count": len(selected),
            "frames": selected_frames,
            "hours_at_fps": selected_frames / args.fps / 3600,
            "delta_frames_from_target": selected_frames - args.target_frames,
            "delta_seconds_from_target": (selected_frames - args.target_frames) / args.fps,
            "episode_indices": ranked_indices,
            "episode_indices_sorted": sorted_indices,
            "episode_lengths_in_rank_order": [
                {"episode_index": index, "length": length} for index, length in selected
            ],
            "ranked_episode_indices_sha256": hashlib.sha256(compact_indices).hexdigest(),
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--subset", action="append", dest="subsets")
    parser.add_argument("--target-frames", type=int, default=1_255_729)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--seed", type=int, default=1000)
    parser.add_argument("--namespace", default="rwrl-piperx-duration-match-v1")
    parser.add_argument("--repo-id", default="MINT-SJTU/RW-RL-Dataset")
    parser.add_argument("--revision", default="ddfd1144bf073b68b180bc5263ddac49c46f68d7")
    parser.add_argument("--reference-subset", default="piperx_insert_copper_screw")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    subsets = tuple(args.subsets or DEFAULT_SUBSETS)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    for subset in subsets:
        manifest = build_manifest(args, subset)
        output_path = args.output_dir / f"{subset}.seed{args.seed}.json"
        output_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        selection = manifest["selection"]
        print(
            f"{subset}: {selection['episode_count']} episodes, "
            f"{selection['frames']} frames, {selection['hours_at_fps']:.6f} h, "
            f"delta={selection['delta_seconds_from_target']:+.3f} s -> {output_path}"
        )


if __name__ == "__main__":
    main()
