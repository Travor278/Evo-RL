# RW-RL SO101 PiperX-duration-matched episode subsets

This package fixes two reproducible SO101 episode subsets whose durations are matched to the
complete `piperx_insert_copper_screw` subset (1,255,729 frames at 30 FPS, about 11.627 hours).

## Fixed baseline results

| Subset | Episodes | Frames | Hours | Difference from PiperX |
| --- | ---: | ---: | ---: | ---: |
| `so101_fold_clothes_left_stack_right` | 108 | 1,258,509 | 11.652861 | +92.667 seconds |
| `so101_put_stationery_table_into_bag` | 397 | 1,256,576 | 11.634963 | +28.233 seconds |

These results use seed `1000` and algorithm namespace `rwrl-piperx-duration-match-v1`.
Because only complete episodes are selected, an exact frame-count match is generally impossible.

## Reproduce the manifests

Requirements: Python 3.10+ and `pyarrow`.

```bash
python build_duration_matched_manifests.py \
  --dataset-root /path/to/RW-RL-Dataset \
  --output-dir ./manifests \
  --seed 1000 \
  --target-frames 1255729
```

The default source revision is pinned to:

```text
ddfd1144bf073b68b180bc5263ddac49c46f68d7
```

The algorithm assigns each episode a SHA-256 rank derived from a compact JSON array containing
the algorithm namespace, repository ID, pinned revision, seed, subset name, and episode index.
It then selects a whole-episode prefix whose total frame count is closest to the PiperX target.
This avoids dependence on NumPy or Python PRNG implementation versions.

## Use a manifest with LeRobot

Extract the fixed episode list:

```bash
MANIFEST=manifests/so101_fold_clothes_left_stack_right.seed1000.json
EPISODES=$(python -c 'import json,sys; print(json.dumps(json.load(open(sys.argv[1]))["selection"]["episode_indices"], separators=(",", ":")))' "$MANIFEST")
```

Pass it to LeRobot:

```bash
python -m lerobot.scripts.lerobot_train \
  --dataset.repo_id=MINT-SJTU/RW-RL-Dataset \
  --dataset.root=/path/to/RW-RL-Dataset/so101_fold_clothes_left_stack_right \
  --dataset.episodes="$EPISODES" \
  ...
```

Use the stationery manifest and dataset root in the same way for
`so101_put_stationery_table_into_bag`.

The JSON manifests are the experiment source of truth: they contain the explicit ranked and
sorted episode lists, per-episode lengths, source metadata SHA-256, source revision, target,
sampling rule, and result checksum. Share this whole directory with collaborators.
